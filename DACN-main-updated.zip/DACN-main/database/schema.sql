-- Schema này được suy ra từ chính các câu query trong backend/server.js
-- (project gốc chưa có sẵn file .sql nào, nên đây là phần mình bổ sung).

CREATE DATABASE IF NOT EXISTS smart_parking_db
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE smart_parking_db;

CREATE TABLE IF NOT EXISTS parking_sessions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  plate_number VARCHAR(30) NOT NULL,
  entry_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  exit_time TIMESTAMP NULL DEFAULT NULL,
  image_in VARCHAR(255) DEFAULT NULL,
  image_out VARCHAR(255) DEFAULT NULL,
  status ENUM('IN', 'OUT') NOT NULL DEFAULT 'IN',
  fee INT DEFAULT NULL
);

-- Index để tra cứu nhanh xe nào đang trong bãi theo biển số
CREATE INDEX idx_plate_status ON parking_sessions (plate_number, status);
