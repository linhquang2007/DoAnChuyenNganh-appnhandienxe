// ==========================================================
// Đổi giá trị này nếu backend Node.js chạy ở địa chỉ/cổng khác
// ==========================================================
const API_BASE = window.location.origin.startsWith("http")
  ? window.location.origin  // nếu mở qua http://localhost:3000 thì tự dùng luôn địa chỉ đó
  : "http://localhost:3000"; // nếu mở file trực tiếp (file://) thì fallback về đây

document.getElementById("apiBaseLabel").textContent = API_BASE;

// Xem trước ảnh khi chọn file
document.getElementById("entryImage").addEventListener("change", (e) => previewImage(e, "entryPreview"));
document.getElementById("exitImage").addEventListener("change", (e) => previewImage(e, "exitPreview"));

function previewImage(event, previewId) {
  const file = event.target.files[0];
  const img = document.getElementById(previewId);
  if (!file) {
    img.classList.add("hidden");
    return;
  }
  img.src = URL.createObjectURL(file);
  img.classList.remove("hidden");
}

function setLoading(resultBoxId, message) {
  document.getElementById(resultBoxId).innerHTML =
    `<span class="spinner"></span> <span class="ml-2 text-slate-500">${message}</span>`;
}

function showResult(resultBoxId, html, ok = true) {
  const color = ok ? "text-green-700 bg-green-50 border-green-200" : "text-red-700 bg-red-50 border-red-200";
  document.getElementById(resultBoxId).innerHTML =
    `<div class="border rounded p-3 ${color}">${html}</div>`;
}

// ---------------- XE VÀO ----------------
async function submitEntry() {
  const fileInput = document.getElementById("entryImage");
  if (!fileInput.files[0]) {
    return showResult("entryResult", "Vui lòng chọn ảnh xe trước.", false);
  }

  const formData = new FormData();
  formData.append("image", fileInput.files[0]);

  setLoading("entryResult", "Đang nhận diện biển số, vui lòng chờ...");

  try {
    const res = await fetch(`${API_BASE}/api/entry`, { method: "POST", body: formData });
    const data = await res.json();

    if (!res.ok) {
      return showResult("entryResult", data.error || "Có lỗi xảy ra.", false);
    }

    showResult(
      "entryResult",
      `✅ <b>${data.message}</b><br/>
       Biển số nhận diện: <b>${data.plate_number}</b><br/>
       Mã lượt gửi: #${data.sessionId}`
    );

    fileInput.value = "";
    document.getElementById("entryPreview").classList.add("hidden");
    loadActiveSessions();
    loadHistory();
  } catch (err) {
    showResult("entryResult", "Không kết nối được tới backend. Kiểm tra backend đã chạy chưa (port 3000).", false);
  }
}

// ---------------- XE RA ----------------
async function submitExit() {
  const fileInput = document.getElementById("exitImage");
  if (!fileInput.files[0]) {
    return showResult("exitResult", "Vui lòng chọn ảnh xe trước.", false);
  }

  const formData = new FormData();
  formData.append("image", fileInput.files[0]);

  setLoading("exitResult", "Đang nhận diện biển số, vui lòng chờ...");

  try {
    const res = await fetch(`${API_BASE}/api/exit`, { method: "POST", body: formData });
    const data = await res.json();

    if (!res.ok) {
      return showResult("exitResult", data.error || "Có lỗi xảy ra.", false);
    }

    showResult(
      "exitResult",
      `✅ <b>${data.message}</b><br/>
       Biển số: <b>${data.plate_number}</b><br/>
       Giờ vào: ${new Date(data.entry_time).toLocaleString("vi-VN")}<br/>
       Phí gửi xe: <b>${Number(data.fee).toLocaleString("vi-VN")}đ</b>`
    );

    fileInput.value = "";
    document.getElementById("exitPreview").classList.add("hidden");
    loadActiveSessions();
    loadHistory();
  } catch (err) {
    showResult("exitResult", "Không kết nối được tới backend. Kiểm tra backend đã chạy chưa (port 3000).", false);
  }
}

// ---------------- BẢNG XE ĐANG TRONG BÃI ----------------
async function loadActiveSessions() {
  const tbody = document.getElementById("activeTableBody");
  const emptyMsg = document.getElementById("activeEmpty");
  try {
    const res = await fetch(`${API_BASE}/api/sessions/active`);
    const rows = await res.json();

    tbody.innerHTML = "";
    emptyMsg.classList.toggle("hidden", rows.length > 0);

    rows.forEach((r) => {
      tbody.innerHTML += `
        <tr class="border-b last:border-0">
          <td class="py-2 pr-4">${r.id}</td>
          <td class="py-2 pr-4 font-medium">${r.plate_number}</td>
          <td class="py-2 pr-4">${new Date(r.entry_time).toLocaleString("vi-VN")}</td>
          <td class="py-2 pr-4">
            ${r.image_in ? `<a class="text-blue-600 hover:underline" href="${API_BASE}/${r.image_in}" target="_blank">Xem ảnh</a>` : "-"}
          </td>
        </tr>`;
    });
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="4" class="py-3 text-red-500">Không tải được dữ liệu — backend có đang chạy không?</td></tr>`;
  }
}

// ---------------- BẢNG LỊCH SỬ ----------------
async function loadHistory() {
  const tbody = document.getElementById("historyTableBody");
  try {
    const res = await fetch(`${API_BASE}/api/sessions`);
    const rows = await res.json();

    tbody.innerHTML = "";
    rows.forEach((r) => {
      const statusBadge =
        r.status === "IN"
          ? `<span class="px-2 py-0.5 rounded text-xs bg-yellow-100 text-yellow-700">Đang gửi</span>`
          : `<span class="px-2 py-0.5 rounded text-xs bg-slate-200 text-slate-700">Đã ra</span>`;

      tbody.innerHTML += `
        <tr class="border-b last:border-0">
          <td class="py-2 pr-4">${r.id}</td>
          <td class="py-2 pr-4 font-medium">${r.plate_number}</td>
          <td class="py-2 pr-4">${new Date(r.entry_time).toLocaleString("vi-VN")}</td>
          <td class="py-2 pr-4">${r.exit_time ? new Date(r.exit_time).toLocaleString("vi-VN") : "-"}</td>
          <td class="py-2 pr-4">${statusBadge}</td>
          <td class="py-2 pr-4">${r.fee ? Number(r.fee).toLocaleString("vi-VN") : "-"}</td>
        </tr>`;
    });
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="6" class="py-3 text-red-500">Không tải được dữ liệu.</td></tr>`;
  }
}

// Tải dữ liệu ngay khi mở trang
loadActiveSessions();
loadHistory();
