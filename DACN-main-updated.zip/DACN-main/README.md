# 🚗 DACN – Bãi đỗ xe thông minh (nhận diện biển số)

Đây là project gốc bạn upload, mình đã:
1. Đọc và giải thích lại đúng những gì code hiện có đang làm.
2. Bổ sung phần **còn thiếu** để chạy được: `requirements.txt` cho AI, file `database/schema.sql`, 2 API còn thiếu, và sửa 1 chỗ dễ gây lỗi (GPU).
3. Thêm **frontend** (`frontend/index.html` + `app.js`) để thao tác qua giao diện web thay vì gõ `curl`.

---

## 1. Nguyên lý hoạt động (đúng theo code hiện có)

Project có 2 service:

```
[Trình duyệt - frontend/index.html]
            │  (upload ảnh xe)
            ▼
   Node.js Backend (server.js, port 3000)
            │  gọi HTTP POST /detect-plate
            ▼
   Python AI Service (main.py, FastAPI, port 5000)
            │
      EasyOCR đọc chữ trong ảnh
            │
   trả về {plate_number}
            ▲
            │
   Node.js lưu kết quả vào MySQL (bảng parking_sessions)
```

### Xe vào bãi (`POST /api/entry`)
1. Frontend gửi ảnh xe lên Node.js.
2. `multer` lưu ảnh vào `backend/uploads/`, đặt tên theo timestamp.
3. Node.js gọi sang Python (`/detect-plate`), truyền **đường dẫn ảnh** (không phải file ảnh) vì cả 2 service dùng chung ổ đĩa (Python đọc file tại `backend/uploads/...`).
4. Bên Python: đọc ảnh bằng `cv2`, cho **toàn bộ ảnh** đi qua `EasyOCR.readtext()`, ghép tất cả đoạn text đọc được thành 1 chuỗi (nối bằng dấu `-`), trả về làm biển số.
5. Nếu gọi Python lỗi (chưa bật service, timeout...) → Node.js vẫn không chặn, cho `plateNumber = "UNKNOWN"` và vẫn lưu vào DB. Đây là thiết kế "graceful fallback" — không cho lỗi AI làm sập luồng nghiệp vụ.
6. Node.js `INSERT` vào bảng `parking_sessions` với `status = 'IN'`.

### Xe ra bãi (`POST /api/exit`)
1. Tương tự bước nhận diện ở trên.
2. Nếu gọi Python lỗi, sẽ dùng `test_plate_number` gửi kèm (nếu có) hoặc chuỗi cứng `"TEST-59X1-123"` — đây là giá trị test có sẵn trong code gốc, chỉ nên dùng khi debug.
3. Tìm trong DB bản ghi `status = 'IN'` mới nhất có cùng biển số.
4. Không tìm thấy → trả lỗi 404 (xe lạ / chưa từng vào).
5. Tìm thấy → tính phí **cố định 5000đ** (chưa tính theo thời gian gửi — xem mục "Hạn chế" bên dưới), cập nhật `exit_time`, `status = 'OUT'`, `fee`.

### ⚠️ Điểm quan trọng cần bạn biết: model YOLO đang KHÔNG được dùng để làm gì cả

Trong `AI/main.py`, project có load `YOLO('yolov8n.pt')` nhưng **biến `model` sau đó không hề được gọi tới** trong hàm `detect_plate()`. Việc đọc biển số hiện tại chỉ do EasyOCR quét thẳng lên toàn bộ ảnh xe.

Điều này không hẳn là lỗi ngẫu nhiên — lý do hợp lý là: `yolov8n.pt` là model **gốc, huấn luyện trên tập COCO** (người, ô tô, xe máy, chó mèo...), **không có class "biển số xe"**, nên dù có dùng nó để detect thì cũng không khoanh được vùng biển số. Muốn dùng YOLO đúng cách (khoanh vùng biển số trước khi OCR, giúp độ chính xác cao hơn nhiều), bạn cần 1 model YOLO **được train riêng** để nhận diện "license plate" — mình có thể giúp bạn tích hợp phần này sau nếu bạn kiếm được/tự train model đó (nói mình biết, mình sẽ sửa `main.py` để crop vùng biển số trước khi đưa vào EasyOCR).

### Hạn chế khác nên biết trước khi dùng thật
- **Phí gửi xe cố định 5000đ** dù gửi 5 phút hay 5 tiếng — chưa tính theo thời gian.
- Kết quả OCR trên ảnh gốc chưa qua crop rất dễ **đọc nhầm chữ khác trong ảnh** (biển quảng cáo, chữ trên xe...), đặc biệt nếu ảnh chụp rộng cả khung cảnh chứ không riêng biển số.
- Chưa có xử lý khi 2 xe khác nhau bị OCR ra trùng biển số (không có kiểm tra "xe này đã ở trong bãi chưa" khi vào — nếu quét trùng biển số 2 lần liên tiếp, hệ thống vẫn tạo 2 session `IN` riêng biệt).

Đây chỉ là ghi chú để bạn nắm rõ hệ thống đang ở mức "chạy được cho demo/đồ án", chưa phải production. Muốn nâng cấp phần nào cứ báo mình.

---

## 2. Những gì mình đã bổ sung vào project

| File | Lý do bổ sung |
|---|---|
| `AI/requirements.txt` | Project gốc chưa có, cần để cài đúng thư viện Python |
| `AI/main.py` (sửa nhỏ) | Tự nhận GPU/CPU thay vì ép cứng `gpu=True` (máy không có GPU NVIDIA sẽ lỗi hoặc chạy sai) |
| `database/schema.sql` | Project gốc chưa có file tạo bảng nào, mình suy ra đúng cấu trúc bảng từ các câu SQL có sẵn trong `server.js` |
| `backend/server.js` (thêm route) | Thêm `GET /api/sessions/active` và `GET /api/sessions` — cần để frontend hiển thị danh sách xe, vì code gốc chỉ có `/api/entry` và `/api/exit` |
| `backend/package.json` | Thêm `mysql2` vào dependencies (code gọi `require('mysql2')` nhưng file này lại khai báo `mssql` — trước đó chạy được là do Node "mượn" `mysql2` từ `node_modules` ở thư mục cha, khá rủi ro) |
| `frontend/index.html`, `frontend/app.js` | Giao diện web bạn yêu cầu thêm |

---

## 3. Cấu trúc project sau khi bổ sung

```
DACN-main/
├── AI/
│   ├── main.py            # FastAPI service, nhận diện biển số
│   ├── requirements.txt   # [MỚI]
│   └── yolov8n.pt
├── backend/
│   ├── server.js          # [ĐÃ SỬA] thêm 2 route + serve frontend
│   ├── package.json       # [ĐÃ SỬA] thêm mysql2
│   ├── .env
│   └── uploads/
├── database/
│   └── schema.sql         # [MỚI]
└── frontend/              # [MỚI]
    ├── index.html
    └── app.js
```

---

## 4. Hướng dẫn chạy từ đầu

### Bước 1 — Tạo database MySQL

```bash
mysql -u root -p < database/schema.sql
```

Kiểm tra lại `backend/.env` đã khớp với MySQL của bạn chưa (đặc biệt `DB_PASSWORD` nếu MySQL có mật khẩu):
```
PORT=3000
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=
DB_NAME=smart_parking_db
```

### Bước 2 — Chạy AI Service (Python)

```bash
cd AI
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

pip install -r requirements.txt
uvicorn main:app --reload --port 5000
```

Lần đầu chạy sẽ hơi lâu vì EasyOCR tự tải thêm model nhận diện chữ. Kiểm tra đã chạy đúng bằng cách mở `http://127.0.0.1:5000/docs` (Swagger UI của FastAPI tự sinh).

### Bước 3 — Chạy Backend (Node.js)

```bash
cd backend
npm install
node server.js
```

Thấy dòng `Server Backend đang chạy tại http://localhost:3000` và `Đã kết nối thành công tới MySQL Database!` là ổn.

### Bước 4 — Mở giao diện Frontend

Vì `server.js` đã được thêm dòng phục vụ file tĩnh từ thư mục `frontend/`, bạn chỉ cần mở trình duyệt:

```
http://localhost:3000
```

(Không cần chạy thêm server nào cho frontend — Node.js đang serve luôn).

Nếu vì lý do nào đó bạn tách frontend ra host riêng, mở trực tiếp `frontend/index.html` bằng trình duyệt cũng được — file `app.js` sẽ tự fallback gọi về `http://localhost:3000`.

### Bước 5 — Thử luồng hoạt động

1. Ở khối **"Xe vào bãi"**: chọn 1 ảnh có biển số xe → bấm **Xử lý xe vào** → xem kết quả biển số nhận diện được, xe sẽ xuất hiện ở bảng "Xe đang trong bãi".
2. Ở khối **"Xe ra bãi"**: chọn ảnh của **cùng chiếc xe đó** (để OCR ra đúng/tương tự biển số) → bấm **Xử lý xe ra** → xem phí phải trả, xe sẽ chuyển sang bảng lịch sử với trạng thái "Đã ra".
3. Nếu OCR đọc bị lệch 1-2 ký tự giữa ảnh vào/ra (rất dễ xảy ra vì đang OCR trực tiếp, chưa crop biển số) → hệ thống trả lỗi 404 "Không tìm thấy xe ở trong bãi" vì biển số không khớp tuyệt đối. Đây là hạn chế đã nêu ở mục 1.

---

## 5. Một số lỗi thường gặp khi chạy

| Lỗi | Nguyên nhân | Cách xử lý |
|---|---|---|
| `Error: connect ECONNREFUSED` khi backend start | MySQL chưa chạy hoặc sai thông tin trong `.env` | Kiểm tra MySQL service đã bật, đúng user/password |
| Backend log `Không thể kết nối tới Python AI` | Chưa bật service Python (port 5000) hoặc bật sai cổng | Bật lại `uvicorn main:app --port 5000`, kiểm tra đúng cổng |
| Cài `easyocr`/`ultralytics` báo lỗi biên dịch | Thiếu một số gói hệ thống hoặc version Python không tương thích | Dùng Python 3.9–3.11, cập nhật `pip install --upgrade pip` trước khi cài |
| Nhận diện biển số sai lung tung | Do đang OCR toàn bộ ảnh (xem mục 1) | Chụp ảnh cận, chỉ lấy vùng biển số rõ nét sẽ cho kết quả tốt hơn nhiều |

---

Nếu muốn mình nâng cấp thêm — ví dụ: tính phí theo giờ thực tế, chặn check-in trùng biển số, hoặc tích hợp YOLO train riêng để crop biển số trước khi OCR — cứ báo mình làm tiếp.
